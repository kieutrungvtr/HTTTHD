//
//  AddCageController.swift
//  test
//
//  Created by Macbook on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class AddCageController: UIViewController {

  @IBOutlet weak var viTriTextField: UITextField!
  @IBOutlet weak var gioiHanTextField: UITextField!
  
  @IBAction func registerDevice(_ sender: Any) {
    if (viTriTextField.text?.isEmpty)! {
      let alertView = UIAlertController.init(title: "Error", message: "vi tri khong duoc trong", preferredStyle: .alert);
      alertView.show(self, sender: nil);
      return
    }
    
    if (gioiHanTextField.text?.isEmpty)! {
      let alertView = UIAlertController.init(title: "Error", message: "gioi han khong duoc trong", preferredStyle: .alert);
      alertView.show(self, sender: nil);
      return
    }

    if (Util.loadHost() == nil) {
      Util.saveHost(backEndUrl: "http://localhost:8080/cowmanage")
    }
    
    let hostUrl = Util.loadHost()! + Util.URL_ADD_CAGE;
    var request = URLRequest(url: URL(string: hostUrl)!)
    
    request.httpMethod = "POST"
    
    let parameter = [
      "viTri" : viTriTextField.text,
      "gioiHan" : gioiHanTextField.text
    ]
    do {
      request.httpBody = try JSONSerialization.data(withJSONObject: parameter, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
    } catch let error {
      print(error.localizedDescription)
    }
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("application/json", forHTTPHeaderField: "Accept")
    
    let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
      if error != nil{
        print(error!.localizedDescription)
        return
      }
      if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
        if let responseData = responseJSON["data"] {
          let aObject = responseData as! [String : AnyObject]
          let cage = Cage()
          cage.gioiHan = aObject["gioiHan"] as! Int
          cage.viTri = aObject["viTri"] as! String
          
          
          // Bounce back to the main thread to update the UI
          DispatchQueue.main.async {
            let alert = UIAlertController(title: "Alert", message: "Register device complete", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { action in
              self.navigationController?.popToRootViewController(animated: true)
              
            }))
            self.present(alert, animated: true, completion: nil)
          }
        }
      }
    })
    task.resume()
  }
}
