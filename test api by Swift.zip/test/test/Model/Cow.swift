//
//  Cow.swift
//  test
//
//  Created by Phuoc Huynh on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import Foundation

class Cow: NSObject{

    var maBo: Int = 0
    
    var dacDiem: String = ""
    
    var ngayNhap = NSDate()
    
    var chuong = Cage()
    
    var nhanVien = Employee()
    
    var benhTat: String = ""
    
    var thietBi = Device()
    
    var lichVatSua: [MilkGetting] = []
    
    var lichChamSocSucKhoe: [CowLog] = []
    
}
