//
//  CowLog.swift
//  test
//
//  Created by Phuoc Huynh on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import Foundation

class CowLog: NSObject {

    var bo = Cow()
    var canNang = 0
    
    var nhietDo = 0
    
    var protit = 0
    
    var chatBeo = 0
    
    var tinhTrang = 0
    
    var ngayCapNhat = NSDate()
    
    var ngayTao = NSDate()
    
}
