//
//  Cage.swift
//  test
//
//  Created by Phuoc Huynh on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import Foundation

class Cage: NSObject {
}
