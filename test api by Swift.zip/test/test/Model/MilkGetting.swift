//
//  Device.swift
//  CowManager
//
//  Created by Phuoc Huynh on 6/10/17.
//  Copyright © 2017 Phuoc Huynh. All rights reserved.
//

import Foundation

class MilkGetting: NSObject {

    var cow = Cow()
    
    var nangSuat = 0
    
    var ngayVatSua = NSDate()
    
    var ngayNhap = NSDate()
    
    var ngayTao = NSDate()
    
}
