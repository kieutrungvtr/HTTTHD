//
//  DeviceUITableViewCell.swift
//  CowManager
//
//  Created by Phuoc Huynh on 6/10/17.
//  Copyright © 2017 Phuoc Huynh. All rights reserved.
//

import Foundation
import UIKit

class DeviceUITableViewCell: UITableViewCell {


    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var providerLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
}
