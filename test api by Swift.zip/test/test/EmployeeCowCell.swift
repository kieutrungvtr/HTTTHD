//
//  EmployeeCowCell.swift
//  test
//
//  Created by Macbook on 6/10/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class EmployeeCowCell: UITableViewCell {
  
  @IBOutlet weak var textFieldMaBo: UILabel!
  @IBOutlet weak var textFieldNgayNhap: UILabel!
  
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
