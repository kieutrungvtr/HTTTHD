//
//  EmployeeCell.swift
//  test
//
//  Created by Macbook on 6/10/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class EmployeeCell: UITableViewCell {
  @IBOutlet weak var textFieldTenNhanVien: UILabel!
  @IBOutlet weak var textFieldSoDienThoai: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
