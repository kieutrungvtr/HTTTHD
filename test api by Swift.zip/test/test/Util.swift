//
//  Util.swift
//  test
//
//  Created by Macbook on 6/10/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import Foundation

class Util {

    static let local = "http://192.168.1.108:8080"
    static let URL_REGISTER_DEVICE = "/device/add"
    static let URL_DEVICE_LIST = "/device/list"
    static let URL_MILK_GETTING_LIST_IN_DAY = "/cow/reportMilkToday"
    static let URL_MILK_GETTING_LIST_TIME_RANGE = "/cow/reportMilkTimeRange"
    
    static func loadHost() -> String? {
        let preferences = UserDefaults.standard
        if (preferences.object(forKey: "backendUrl") == nil) {
            // Does not exist
            return nil
        } else {
            return preferences.string(forKey: "backendUrl")!
            
        }
    }
    
    static func saveHost(backEndUrl: String) {
        let preferences = UserDefaults.standard
        preferences.set(backEndUrl, forKey: "backendUrl")
        preferences.synchronize()
    }
  
    
  ///
  static func loadRefId() -> Int? {
    let preferences = UserDefaults.standard
    if (preferences.object(forKey: "refId") == nil) {
      // Does not exist
      return nil
    } else {
      return preferences.integer(forKey: "refId")
      
    }
  }
  
  static func saveRefId(refId: Int) {
    let preferences = UserDefaults.standard
    preferences.set(refId, forKey: "refId")
    preferences.synchronize()
  }
}
