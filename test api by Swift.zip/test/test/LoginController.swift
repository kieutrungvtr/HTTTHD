//
//  LoginController.swift
//  test
//
//  Created by Macbook on 6/10/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class LoginController: UIViewController {
  @IBOutlet weak var userName: UITextField!
  @IBOutlet weak var password: UITextField!

  @IBAction func Login(_ sender: Any) {
    
    if userName.text == "thai" && password.text == "1234" {
      performSegue(withIdentifier: "manaSeque", sender: self)
    }else if userName.text == "ngoc" && password.text == "1234" {
      performSegue(withIdentifier: "employSeque", sender: self)
    }
  }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
