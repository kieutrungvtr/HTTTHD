//
//  LoginController.swift
//  test
//
//  Created by Macbook on 6/10/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class LoginController: UIViewController {
    
  @IBOutlet weak var userName: UITextField!
  @IBOutlet weak var password: UITextField!
  @IBOutlet weak var hostBackEnd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let hostUrl = Util.loadHost();
        if (hostUrl != nil) {
            hostBackEnd.text = hostUrl;
        }
        
    }
    
  @IBAction func Login(_ sender: Any) {
    
    if ((userName.text?.isEmpty)! && (password.text?.isEmpty)!) {
        let alert = UIAlertController(title: "Error", message: "The username and password are not empty", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    } else if (userName.text?.isEmpty)! {
        let alert = UIAlertController(title: "Error", message: "The username is not empty", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    } else if (password.text?.isEmpty)! {
        let alert = UIAlertController(title: "Error", message: "The password is not empty", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    } else if (hostBackEnd.text?.isEmpty)!{
        let alert = UIAlertController(title: "Error", message: "Backend URL is not empty", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    } else {
        if userName.text == "thai" && password.text == "1234" {
            Util.saveHost(backEndUrl: hostBackEnd.text!)
            performSegue(withIdentifier: "manaSeque", sender: self)
        }else if userName.text == "ngoc" && password.text == "1234" {
            Util.saveHost(backEndUrl: hostBackEnd.text!)
            performSegue(withIdentifier: "employSeque", sender: self)
        } else {
            let alert = UIAlertController(title: "Error", message: "The username or password is invalid", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
        }
    }
    
    
    
  }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
