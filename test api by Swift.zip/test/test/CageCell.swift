//
//  CageCell.swift
//  test
//
//  Created by Macbook on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class CageCell: UITableViewCell {

  @IBOutlet weak var idLabel: UILabel!
  @IBOutlet weak var viTriLabel: UILabel!
  @IBOutlet weak var gioiHanLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
