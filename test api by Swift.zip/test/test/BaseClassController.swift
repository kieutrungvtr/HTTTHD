//
//  BaseClassController.swift
//  test
//
//  Created by Macbook on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import Foundation
import UIKit

class BaseClassViewController : UITabBarController {

  @IBInspectable var defaultIndex: Int = 0
  
  override func viewDidLoad() {
    super.viewDidLoad()
    selectedIndex = defaultIndex
  }
  
}
