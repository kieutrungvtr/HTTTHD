//
//  EmployeeCowController.swift
//  test
//
//  Created by Macbook on 6/10/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class EmployeeCowController: UITableViewController {
  
  
  let myNetWork = "http://192.168.1.108:8080/"
  var maNhanVien:Int!
  var maBoArray = [Int]()
  var dacDiemArray = [String]()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    self.downLoadJSonwithUrl()
    
  }
  func downLoadJSonwithUrl(){
    let url = URL(string: myNetWork+"cowmanage/cow/listByMaNv")!
    let jsonDict = ["maNhanVien" : maNhanVien]
    let jsonData = try! JSONSerialization.data(withJSONObject: jsonDict, options: [])
    
    var request = URLRequest(url: url)
    request.httpMethod = "post"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.httpBody = jsonData
    
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
      if let error = error {
        print("error:", error)
        return
      }
      if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
        if let dataArray = jsonObj!.value(forKey: "data") as? NSArray {
          for actor in dataArray{
            if let dataDict = actor as? NSDictionary {
              if let name = dataDict.value(forKey: "maBo") {
                self.maBoArray.append(name as! Int)
              }
              if let name = dataDict.value(forKey: "dacDiem") {
                self.dacDiemArray.append(name as! String)
              }
            }
          }
        }
        OperationQueue.main.addOperation({
          self.tableView.reloadData()
        })
      }
    }
    task.resume()
  }
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    print(maBoArray)
    return maBoArray.count
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cellBoThuocNhanVien") as! EmployeeCowCell
    cell.textFieldMaBo.text = String(maBoArray[indexPath.row])
    cell.textFieldNgayNhap.text = dacDiemArray[indexPath.row]
    
    return cell
  }

}
