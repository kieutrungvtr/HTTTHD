//
//  CageController.swift
//  test
//
//  Created by Macbook on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class CageController: UITableViewController {

  var cages: [Cage] = []
  
  override func viewWillAppear(_ animated: Bool) {
    loadlistCages();
  }
  
  func loadlistCages() {
    // Clear old list devices
    self.cages = [];
    if (Util.loadHost() == nil) {
      Util.saveHost(backEndUrl: "http://localhost:8080/cowmanage")
    }
    let hostUrl = Util.loadHost()! + Util.URL_CAGE_LIST;
    var request = URLRequest(url: URL(string: hostUrl)!)
    request.httpMethod = "GET"
    let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
      if error != nil{
        print(error!.localizedDescription)
        return
      }
      if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
        if let responseData = responseJSON["data"] {
          for index in 0...responseData.count-1 {
            let aObject = responseData[index] as! [String : AnyObject]
            let cage = Cage()
            cage.maChuong = aObject["maChuong"] as! Int
            cage.viTri = aObject["viTri"] as! String
            cage.gioiHan = aObject["gioiHan"] as! Int
            self.cages.append(cage);
          }
        }
      }
      DispatchQueue.global(qos: .userInitiated).async {
        DispatchQueue.main.async {
          self.tableView.reloadData()
        }
      }
    })
    task.resume()
  }
  
  
  
  
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return cages.count
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cageIdentifier", for: indexPath) as! CageCell
    if(indexPath.item % 2 == 0){
      cell.backgroundColor = UIColor.clear
    }else{
      cell.backgroundColor = UIColor.white.withAlphaComponent(0.2)
      cell.textLabel?.backgroundColor = UIColor.white.withAlphaComponent(0.0)
    }
    let cage = cages[indexPath.row]
    cell.idLabel.text = String(cage.maChuong)
    cell.viTriLabel.text = cage.viTri
    cell.gioiHanLabel.text = String(cage.gioiHan)
    return cell
  }


}
