//
//  DeviceListViewController.swift
//  CowManager
//
//  Created by duynt on 6/10/17.
//  Copyright © 2017 duynt. All rights reserved.
//

import Foundation

import UIKit

class DeviceListViewController: UITableViewController {
    
    
    var devices: [Device] = []
    
    func loadlistDevices() {
        // Clear old list devices
        self.devices = [];
        let hostUrl = Util.loadHost()! + Util.URL_DEVICE_LIST;
        var request = URLRequest(url: URL(string: hostUrl)!)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
            if error != nil{
                print(error!.localizedDescription)
                return
            }
            if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
                if let responseData = responseJSON["data"] {
                    for index in 0...responseData.count-1 {
                        let aObject = responseData[index] as! [String : AnyObject]
                        let device = Device()
                        device.maTb = aObject["maTb"] as! Int
                        device.moTa = aObject["moTa"] as! String
                        device.nhaCungCap = aObject["nhaCungCap"] as! String
                        device.tenTb = aObject["tenTb"] as! String
                        device.tinhTrang = aObject["tinhTrang"] as! Int
                        self.devices.append(device);
                    }
                }
            }
            self.tableView.reloadData();
        })
        task.resume()
    }
    
    override func viewDidLoad() {
        loadlistDevices();
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return devices.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "deviceIdentifier", for: indexPath) as! DeviceUITableViewCell
        let device = devices[indexPath.row]
            cell.idLabel.text = String(device.maTb)
            cell.descLabel.text = device.moTa
            cell.nameLabel.text = device.tenTb
            cell.providerLabel.text = device.nhaCungCap
            cell.statusLabel.text = String(device.tinhTrang)
        return cell
    }
    
}
