//
//  DeviceListViewController.swift
//  CowManager
//
//  Created by duynt on 6/10/17.
//  Copyright © 2017 duynt. All rights reserved.
//

import Foundation

import UIKit

class DeviceListViewController: UITableViewController {
    
    
  var devices: [Device] = []
  
  func loadlistDevices() {
    // Clear old list devices
    self.devices = [];
    if (Util.loadHost() == nil) {
      Util.saveHost(backEndUrl: "http://localhost:8080/cowmanage")
    }
    let hostUrl = Util.loadHost()! + Util.URL_DEVICE_LIST;
    var request = URLRequest(url: URL(string: hostUrl)!)
    request.httpMethod = "GET"
    let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
      if error != nil{
        print(error!.localizedDescription)
        return
      }
      if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
        if let responseData = responseJSON["data"] {
          for index in 0...responseData.count-1 {
            let aObject = responseData[index] as! [String : AnyObject]
            let device = Device()
            device.maTb = aObject["maTb"] as! Int
            device.moTa = aObject["moTa"] as! String
            device.nhaCungCap = aObject["nhaCungCap"] as! String
            device.tenTb = aObject["tenTb"] as! String
            device.tinhTrang = aObject["tinhTrang"] as! Int
            self.devices.append(device);
          }
        }
      }
      DispatchQueue.global(qos: .userInitiated).async {
         DispatchQueue.main.async {
          self.tableView.reloadData()
        }
      }
    })
    task.resume()
  }
  
//  override func viewDidLoad() {
//    loadlistDevices();
//  }
  override func viewWillAppear(_ animated: Bool) {
    loadlistDevices()
  }
  
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return devices.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      let cell = tableView.dequeueReusableCell(withIdentifier: "deviceIdentifier", for: indexPath) as! DeviceUITableViewCell
      if(indexPath.item % 2 == 0){
        cell.backgroundColor = UIColor.clear
      }else{
        cell.backgroundColor = UIColor.white.withAlphaComponent(0.2)
        cell.textLabel?.backgroundColor = UIColor.white.withAlphaComponent(0.0)
      }
      let device = devices[indexPath.row]
      cell.idLabel.text = String(device.maTb)
      cell.descLabel.text = device.moTa
      cell.nameLabel.text = device.tenTb
      cell.providerLabel.text = device.nhaCungCap
      cell.statusLabel.text = String(device.tinhTrang)
      return cell
  }
  
  
  
}
