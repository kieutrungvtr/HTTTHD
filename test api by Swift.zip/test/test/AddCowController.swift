//
//  AddCowController.swift
//  test
//
//  Created by Macbook on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class AddCowController: UIViewController {

  @IBOutlet weak var textFieldMaNhanVien: UITextField!
  @IBOutlet weak var textFieldMaThietBi: UITextField!
  @IBOutlet weak var textFieldDacDiem: UITextField!
  @IBOutlet weak var textFieldBenhTat: UITextField!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    
  }
  
  @IBAction func themBo(_ sender: UIButton) {
    
    if (Util.loadHost() == nil) {
      Util.saveHost(backEndUrl: "http://localhost:8080/cowmanage")
    }
    let hostUrl = Util.loadHost()! + Util.URL_ADD_COW;
    var request = URLRequest(url: URL(string: hostUrl)!)
    
    if (textFieldMaNhanVien.text?.isEmpty)! {
      let alertView = UIAlertController.init(title: "Error", message: "ma nhan vien khong duoc trong", preferredStyle: .alert);
      alertView.show(self, sender: nil);
      return
    }
    
    if (textFieldMaThietBi.text?.isEmpty)! {
      let alertView = UIAlertController.init(title: "Error", message: "ma thiet bi khong duoc trong", preferredStyle: .alert);
      alertView.show(self, sender: nil);
      return
    }
    
    if (textFieldDacDiem.text?.isEmpty)! {
      let alertView = UIAlertController.init(title: "Error", message: "dac diem khong duoc trong", preferredStyle: .alert);
      alertView.show(self, sender: nil);
      return
    }
    if (textFieldBenhTat.text?.isEmpty)! {
      let alertView = UIAlertController.init(title: "Error", message: "benh tat khong duoc trong", preferredStyle: .alert);
      alertView.show(self, sender: nil);
      return
    }
    
    let jsonDict = ["maNhanVien" : Int(textFieldMaNhanVien.text!),
                    "maThietBi" : Int(textFieldMaThietBi.text!),
                    "dacDiem" : textFieldDacDiem.text,
                    "benhTat" : textFieldBenhTat.text,
                    "ngayNhap": 0
                  ] as [String : Any]
    let jsonData = try! JSONSerialization.data(withJSONObject: jsonDict, options: [])
    
    request.httpMethod = "post"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.httpBody = jsonData
    
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
      if let error = error {
        print("error:", error)
        return
      }
      
      do {
        guard let data = data else { return }
        guard let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else { return }
        print("json:", json)
      } catch {
        print("error:", error)
      }
    }
    task.resume()
    let alert = UIAlertController(title: "Yeah", message: "Thêm nhân viên thành công", preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: "Ok", style: .default))
    present(alert, animated: true)
    
    textFieldMaNhanVien.text = ""
    textFieldMaThietBi.text = ""
    textFieldDacDiem.text = ""
    textFieldBenhTat.text = ""
  }
  

}
