//
//  AddEmployeeController.swift
//  test
//
//  Created by Macbook on 6/10/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class AddEmployeeController: UIViewController {

  
  @IBOutlet weak var textFieldTenNhanVien: UITextField!
  @IBOutlet weak var textFieldNgaysinh: UITextField!
  @IBOutlet weak var textFieldSdt: UITextField!
  @IBOutlet weak var textFieldDiaChi: UITextField!
  @IBOutlet weak var textFieldBoPhan: UITextField!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    
  }

  @IBAction func themNhanVien(_ sender: UIButton) {
    let myNetWork = "http://192.168.1.108:8080/"
    
    let url = URL(string: myNetWork+"cowmanage/employee/add")!
    let jsonDict = ["maNv" : 1324,
                    "tenNv" : textFieldTenNhanVien.text,
                    "ngaySinh" : textFieldNgaysinh.text,
                    "soDt" : Int(textFieldSdt.text!),
                    "diaChi" : textFieldDiaChi.text,
                    "boPhan" : textFieldBoPhan.text,
                    "chucDanh" : 2] as [String : Any]
    let jsonData = try! JSONSerialization.data(withJSONObject: jsonDict, options: [])
    
    var request = URLRequest(url: url)
    request.httpMethod = "post"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.httpBody = jsonData
    
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
      if let error = error {
        print("error:", error)
        return
      }
      
      do {
        guard let data = data else { return }
        guard let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else { return }
        print("json:", json)
      } catch {
        print("error:", error)
      }
    }
    task.resume()
    let alert = UIAlertController(title: "Yeah", message: "Thêm nhân viên thành công", preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: "Ok", style: .default))
    present(alert, animated: true)

    textFieldTenNhanVien.text = ""
    textFieldNgaysinh.text = ""
    textFieldSdt.text = ""
    textFieldDiaChi.text = ""
    textFieldBoPhan.text = ""
  }
}
