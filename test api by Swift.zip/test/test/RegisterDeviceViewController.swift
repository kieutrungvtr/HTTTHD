//
//  RegisterDeviceViewController.swift
//  CowManager
//
//  Created by Phuoc Huynh on 6/10/17.
//  Copyright © 2017 Phuoc Huynh. All rights reserved.
//

import Foundation
import UIKit

class RegisterDeviceViewController: UIViewController {
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var providerTextField: UITextField!
    @IBOutlet weak var descTextField: UITextField!
    
    @IBAction func registerDevice(_ sender: Any) {
        if (nameTextField.text?.isEmpty)! {
            let alertView = UIAlertController.init(title: "Error", message: "The device name is not empty", preferredStyle: .alert);
            alertView.show(self, sender: nil);
            return
        }
        
        if (providerTextField.text?.isEmpty)! {
            let alertView = UIAlertController.init(title: "Error", message: "The device provider is not empty", preferredStyle: .alert);
            alertView.show(self, sender: nil);
            return
        }
        
        if (descTextField.text?.isEmpty)! {
            let alertView = UIAlertController.init(title: "Error", message: "The device description is not empty", preferredStyle: .alert);
            alertView.show(self, sender: nil);
            return
        }
        let hostUrl = Util.loadHost()! + Util.URL_REGISTER_DEVICE;
        var request = URLRequest(url: URL(string: hostUrl)!)
        
        request.httpMethod = "POST"
        
        let parameter = [
            "tenTb" : nameTextField.text,
            "moTa" : descTextField.text,
            "nhaCungCap" : providerTextField.text]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameter, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
        } catch let error {
            print(error.localizedDescription)
        }
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
            if error != nil{
                print(error!.localizedDescription)
                return
            }
            if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
                if let responseData = responseJSON["data"] {
                    let aObject = responseData as! [String : AnyObject]
                    let device = Device()
                    device.maTb = aObject["maTb"] as! Int
                    device.moTa = aObject["moTa"] as! String
                    device.nhaCungCap = aObject["nhaCungCap"] as! String
                    device.tenTb = aObject["tenTb"] as! String
                    device.tinhTrang = aObject[ "tinhTrang"] as! Int
                    
                        // Bounce back to the main thread to update the UI
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Alert", message: "Register device complete", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { action in
                            self.navigationController?.popToRootViewController(animated: true)
                            
                        }))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        })
        task.resume()

    }
    
}
