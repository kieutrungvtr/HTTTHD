//
//  EmployeeController.swift
//  test
//
//  Created by Macbook on 6/10/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import UIKit

class EmployeeController: UITableViewController {
  
  var tenArray = [String]()
  var soDienThoaiArray = [Int]()
  var maArray = [Int]()
  override func viewDidLoad() {
    super.viewDidLoad()
    
   
  }
  
  override func viewWillAppear(_ animated: Bool) {
    downLoadJSonwithUrl()
  }

  func downLoadJSonwithUrl() {
    
    self.maArray = []
    self.tenArray = []
    self.soDienThoaiArray = []
    
    let myNetWork = "http://192.168.1.108:8080/"
    let url = URL(string: myNetWork+"cowmanage/employee/list")
    
    URLSession.shared.dataTask(with: (url! as? URL)!, completionHandler: {(data, response, error)->
      Void in
      if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary{
//        print(jsonObj!.value(forKey: "data"))
        if let dataArray = jsonObj!.value(forKey: "data") as? NSArray {
          for data in dataArray{
            if let dataDict = data as? NSDictionary {
              if let name = dataDict.value(forKey: "tenNv") {
                self.tenArray.append(name as! String)
              }
              if let name = dataDict.value(forKey: "soDt") {
                self.soDienThoaiArray.append(name as! Int)
              }
              if let name = dataDict.value(forKey: "maNv") {
                self.maArray.append(name as! Int)
              }
            }
          }
        }
        OperationQueue.main.addOperation({
          self.tableView.reloadData()
        })
      }
    }).resume()
    
  }
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return tenArray.count
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! EmployeeCell
    cell.textFieldTenNhanVien.text = tenArray[indexPath.row]
    cell.textFieldSoDienThoai.text = String(soDienThoaiArray[indexPath.row])
    return cell
  }
  
  override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    let employeeCowController = EmployeeCowController()
    employeeCowController.maNhanVien = maArray[indexPath.row]
    print(employeeCowController.maNhanVien)
    // save manv
    Util.saveRefId(refId: employeeCowController.maNhanVien)
    let navController = UINavigationController(rootViewController: employeeCowController)
    present(navController, animated: true, completion: nil)
  }
  
 

}
