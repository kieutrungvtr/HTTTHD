//
//  ReportViewController.swift
//  test
//
//  Created by Phuoc Huynh on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import Foundation
import UIKit
import Charts

class ReportViewController : UIViewController {
    
    let myNetWork = "http://192.168.1.108:8080/cowmanage/"
  
    @IBOutlet weak var reportInMonthChartView: LineChartView!
    
    @IBOutlet weak var reportInDayChartView: LineChartView!
    
    var reportDay: [MilkGetting] = []
    
    var reportTimeRange: [MilkGetting] = []
    
    override func viewDidLoad() {
        loadReportInDay()
        loadReportInTimeRange()
        
        setUpChartInDay()
        setUpChartTimeRange()
    }
    
    func setUpChartInDay() {
        // 1 - creating an array of data entries
        var yValues : [ChartDataEntry] = [ChartDataEntry]()
        
        for i in 0 ..< reportDay.count {
            yValues.append(ChartDataEntry(x: Double(i + 1), y: Double(reportDay[i].nangSuat)))
        }
        
        let data = LineChartData()
        let ds = LineChartDataSet(values: yValues, label: "Nang suat")
        ds.setColor(UIColor.blue)
        //    lineChartDataSet.drawCubicEnabled = true
        ds.mode = .cubicBezier
        ds.drawCirclesEnabled = false
        ds.lineWidth = 1.0
        ds.circleRadius = 5.0
        ds.highlightColor = UIColor.red
        ds.drawHorizontalHighlightIndicatorEnabled = true
        
        data.addDataSet(ds)
        self.reportInDayChartView.chartDescription?.text = ""
        self.reportInDayChartView.data = data

    }
    
    func setUpChartTimeRange() {
        // 1 - creating an array of data entries
        var yValues : [ChartDataEntry] = [ChartDataEntry]()
        
        for i in 0 ..< reportTimeRange.count {
            yValues.append(ChartDataEntry(x: Double(i + 1), y: Double(reportTimeRange[i].nangSuat)))
        }
        
        let data = LineChartData()
        let ds = LineChartDataSet(values: yValues, label: "Nang suat")
        ds.setColor(UIColor.blue)
        //    lineChartDataSet.drawCubicEnabled = true
        ds.mode = .cubicBezier
        ds.drawCirclesEnabled = false
        ds.lineWidth = 1.0
        ds.circleRadius = 5.0
        ds.highlightColor = UIColor.red
        ds.drawHorizontalHighlightIndicatorEnabled = true
        
        data.addDataSet(ds)
        self.reportInMonthChartView.chartDescription?.text = ""
        self.reportInMonthChartView.data = data
        
    }

    
    func loadReportInDay() {
        // Clear old list devices
        self.reportDay = [];
        let hostUrl = myNetWork + "/cow/reportMilkToday";
        var request = URLRequest(url: URL(string: hostUrl)!)
        request.httpMethod = "POST"
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
            if error != nil{
                print(error!.localizedDescription)
                return
            }
            if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
                if let responseData = responseJSON["data"] {
                    for index in 0...responseData.count-1 {
                        let aObject = responseData[index] as! [String : AnyObject]
                        let milkGetting = MilkGetting()
                        
                        var rawCow = aObject["cow"] as! [String: AnyObject]
                        var cow = Cow()
                        cow.benhTat = rawCow["benhTat"] as! String
                        cow.dacDiem = rawCow["dacDiem"] as! String
                        cow.maBo = 2224 //rawCow["maBo"] as! Int
                    
                        milkGetting.cow = cow
                        milkGetting.nangSuat = aObject["nangSuat"] as! Int
                        milkGetting.ngayNhap = aObject["ngayNhap"] as! NSDate
                        milkGetting.ngayTao = aObject["ngayTao"] as! NSDate
                        milkGetting.ngayVatSua = aObject["ngayVatSua"] as! NSDate
                        self.reportDay.append(milkGetting);
                    }
                }
            }
        })
        task.resume()
    }
    
    func loadReportInTimeRange() {
        // Clear old list devices
        self.reportTimeRange = [];
        let hostUrl = "http://192.168.1.108:8080" + Util.URL_MILK_GETTING_LIST_TIME_RANGE;
        var request = URLRequest(url: URL(string: hostUrl)!)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
            if error != nil{
                print(error!.localizedDescription)
                return
            }
            if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
                if let responseData = responseJSON["data"] {
                    for index in 0...responseData.count-1 {
                        let aObject = responseData[index] as! [String : AnyObject]
                        let milkGetting = MilkGetting()
                        
                        var rawCow = aObject["cow"] as! [String: AnyObject]
                        var cow = Cow()
                        cow.benhTat = rawCow["benhTat"] as! String
                        cow.dacDiem = rawCow["dacDiem"] as! String
                        cow.maBo = rawCow["maBo"] as! Int
                        
                        milkGetting.cow = cow
                        milkGetting.nangSuat = aObject["nangSuat"] as! Int
                        milkGetting.ngayNhap = aObject["ngayNhap"] as! NSDate
                        milkGetting.ngayTao = aObject["ngayTao"] as! NSDate
                        milkGetting.ngayVatSua = aObject["ngayVatSua"] as! NSDate
                        self.reportTimeRange.append(milkGetting);
                    }
                }
            }
        })
        task.resume()
    }
}
