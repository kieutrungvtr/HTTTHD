//
//  ReportViewController.swift
//  test
//
//  Created by Phuoc Huynh on 6/11/17.
//  Copyright © 2017 bibu. All rights reserved.
//

import Foundation
import UIKit
import Charts

class ReportViewController : UIViewController {
    
  
    @IBOutlet weak var reportInMonthChartView: BarChartView!
    
    @IBOutlet weak var reportInDayChartView: BarChartView!
    
    var reportDay: [MilkGetting] = []
    
    var reportTimeRange: [MilkGetting] = []
    
    override func viewDidLoad() {
        loadReportInDay()
        loadReportInTimeRange()
    }
    
    func setUpChartInDay() {
      var dataEntries: [ChartDataEntry] = []
      var titles = [String]()
      
      for i in 0 ..< reportDay.count {
        let maBo = reportDay[i].cow.maBo
        let nangSuat = reportDay[i].nangSuat
        titles.append(String(maBo))
        let dataEntry = BarChartDataEntry(x: Double(i), y: Double(nangSuat))
        dataEntries.append(dataEntry)
      }
      
      let data = BarChartData()
      let ds = BarChartDataSet(values: dataEntries, label: "Nang suat")
      ds.setColor(UIColor.blue)
      data.setDrawValues(false)
      
      data.addDataSet(ds)
      self.reportInDayChartView.chartDescription?.text = ""
      self.reportInDayChartView.xAxis.labelPosition = .bottom
      
      self.reportInDayChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values:titles)
      self.reportInDayChartView.xAxis.granularity = 1
      
      self.reportInDayChartView.data = data
  }
    
  func setUpChartTimeRange() {
    var dataEntries: [ChartDataEntry] = []
    var titles = [String]()
    
    for i in 0 ..< reportTimeRange.count {
      let maBo = reportTimeRange[i].cow.maBo
      let nangSuat = reportTimeRange[i].nangSuat
      titles.append(String(maBo))
      let dataEntry = BarChartDataEntry(x: Double(i), y: Double(nangSuat))
      dataEntries.append(dataEntry)
    }
    
    let data = BarChartData()
    let ds = BarChartDataSet(values: dataEntries, label: "Nang suat")
    ds.setColor(UIColor.blue)
    data.setDrawValues(false)
    
    data.addDataSet(ds)
    self.reportInMonthChartView.chartDescription?.text = ""
    //        self.reportInMonthChartView.legend.enabled = true
    self.reportInMonthChartView.xAxis.labelPosition = .bottom
    
    self.reportInMonthChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values:titles)
    self.reportInMonthChartView.xAxis.granularity = 1
    
    self.reportInMonthChartView.data = data
    
  }


  
    func loadReportInDay() {
        // Clear old list report
        self.reportDay = [];
        if (Util.loadHost() == nil) {
          Util.saveHost(backEndUrl: "http://localhost:8080/cowmanage")
        }
        let hostUrl = Util.loadHost()! + Util.URL_MILK_GETTING_LIST_IN_DAY;
        var request = URLRequest(url: URL(string: hostUrl)!)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
            if error != nil{
                print(error!.localizedDescription)
                return
            }
            if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
                if let responseData = responseJSON["data"] {
                    for index in 0...responseData.count-1 {
                        let aObject = responseData[index] as! [String : AnyObject]
                        let milkGetting = MilkGetting()
                      
                        var rawCow = aObject["bo"] as! [String: AnyObject]
                        let cow = Cow()
                      
                        var benhTat = rawCow["benhTat"] as? String
                        if (benhTat == nil) {
                          benhTat = ""
                        }
                        cow.benhTat = benhTat!
                      
                        var dacDiem = rawCow["dacDiem"] as? String
                        if (dacDiem == nil) {
                          dacDiem = ""
                        }
                        cow.dacDiem = dacDiem!
                        cow.maBo = rawCow["maBo"] as! Int
                      
                        milkGetting.cow = cow
                        milkGetting.nangSuat = aObject["nangSuat"] as! Int
                        // The type of time from response data is long -> convert long to NSDate by below function
                        milkGetting.ngayNhap = NSDate(timeIntervalSince1970: TimeInterval(aObject["ngayNhap"] as! CUnsignedLong))
                        milkGetting.ngayTao = NSDate(timeIntervalSince1970: TimeInterval(aObject["ngayTao"] as! CUnsignedLong))
                        milkGetting.ngayVatSua = NSDate(timeIntervalSince1970: TimeInterval(aObject["ngayVatSua"] as! CUnsignedLong))
                        self.reportDay.append(milkGetting);
                        DispatchQueue.main.async {
                          self.setUpChartInDay()
                        }
                    }
                }
            }
        })
        task.resume()
    }
    
    func loadReportInTimeRange() {
        self.reportTimeRange = [];
        let hostUrl = Util.local + Util.URL_MILK_GETTING_LIST_TIME_RANGE;
        var request = URLRequest(url: URL(string: hostUrl)!)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { data,response,error in
            if error != nil{
                print(error!.localizedDescription)
                return
            }
            if let responseJSON = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? [String:AnyObject]{
                if let responseData = responseJSON["data"] {
                    for index in 0...responseData.count-1 {
                        let aObject = responseData[index] as! [String : AnyObject]
                        let milkGetting = MilkGetting()
                        
                        var rawCow = aObject["bo"] as! [String: AnyObject]
                        let cow = Cow()
                        var benhTat = rawCow["benhTat"] as? String
                        if (benhTat == nil) {
                          benhTat = ""
                        }
                        cow.benhTat = benhTat!
                      
                        var dacDiem = rawCow["dacDiem"] as? String
                        if (dacDiem == nil) {
                          dacDiem = ""
                        }
                        cow.dacDiem = dacDiem!

                        cow.maBo = rawCow["maBo"] as! Int
                      
                        milkGetting.cow = cow
                        milkGetting.nangSuat = aObject["nangSuat"] as! Int
                        milkGetting.ngayNhap = NSDate(timeIntervalSince1970: TimeInterval(aObject["ngayNhap"] as! CUnsignedLong))
                        milkGetting.ngayTao = NSDate(timeIntervalSince1970: TimeInterval(aObject["ngayTao"] as! CUnsignedLong))
                        milkGetting.ngayVatSua = NSDate(timeIntervalSince1970: TimeInterval(aObject["ngayVatSua"] as! CUnsignedLong))
                      self.reportTimeRange.append(milkGetting);
                        DispatchQueue.main.async {
                          self.setUpChartInDay()
                        }

                        self.reportTimeRange.append(milkGetting);
                        //Main thread update UI
                        DispatchQueue.main.async {
                          self.setUpChartTimeRange()
                       }
                    }
                }
            }
        })
        task.resume()
    }
}
